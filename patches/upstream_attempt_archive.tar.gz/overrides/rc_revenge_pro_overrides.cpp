// Per-game overrides for RC Revenge Pro (SLUS-20153), applied during loadELF.
//
// The game's file layer (FMFileFetchSectors) reads through a 96-sector cache
// aligned to multiples of 96 sectors, so it requests sectors outside the file
// it opened. The runtime's sceCdSearchFile hands out per-file pseudo sector
// numbers that cannot satisfy those reads. Here we report each file's real
// position on the disc and serve all reads from the ISO, as the hardware does.

#include "game_overrides.h"
#include "ps2_recompiled_functions.h"
#include "ps2_runtime.h"
#include "ps2_runtime_macros.h"
#include "runtime/ee_scheduler.h"
#include "ps2_stubs.h"

#include <filesystem>

#include <algorithm>
#include <array>
#include <chrono>
#include <cstdlib>
#include <thread>
#include <cctype>
#include <cstring>
#include <fstream>
#include <iostream>
#include <string>
#include <unordered_map>
#include <vector>

namespace
{
    constexpr uint32_t kSceCdSearchFileAddr = 0x001CC110u;
    constexpr uint32_t kSectorSize = 2048u;
    constexpr const char *kIsoName = "RC Revenge Pro (USA).iso";

    struct IsoFile
    {
        uint32_t lsn;
        uint32_t size;
    };

    std::unordered_map<std::string, IsoFile> g_isoFiles;

    uint32_t le32(const uint8_t *p)
    {
        return p[0] | (p[1] << 8) | (p[2] << 16) | (static_cast<uint32_t>(p[3]) << 24);
    }

    // Guest paths look like "\SPLASH\LEG_N.BMP;1" and may carry a device prefix.
    std::string normalize(std::string path)
    {
        if (const auto colon = path.find(':'); colon != std::string::npos)
        {
            path.erase(0, colon + 1);
        }
        if (const auto version = path.rfind(';'); version != std::string::npos)
        {
            path.erase(version);
        }
        std::replace(path.begin(), path.end(), '\\', '/');
        while (!path.empty() && path.front() == '/')
        {
            path.erase(0, 1);
        }
        std::transform(path.begin(), path.end(), path.begin(),
                       [](unsigned char c) { return static_cast<char>(std::toupper(c)); });
        return path;
    }

    void walkDirectory(std::ifstream &iso, uint32_t lsn, uint32_t size, const std::string &prefix, int depth)
    {
        if (depth > 16)
        {
            return;
        }

        std::vector<uint8_t> dir(size);
        iso.clear();
        iso.seekg(static_cast<std::streamoff>(lsn) * kSectorSize);
        iso.read(reinterpret_cast<char *>(dir.data()), static_cast<std::streamsize>(size));

        for (uint32_t pos = 0; pos + 33 < size;)
        {
            const uint8_t recordLen = dir[pos];
            if (recordLen == 0)
            {
                // Records never cross a sector boundary; the rest of this one is padding.
                pos = (pos / kSectorSize + 1) * kSectorSize;
                continue;
            }

            const uint8_t *record = dir.data() + pos;
            const uint32_t extent = le32(record + 2);
            const uint32_t dataLen = le32(record + 10);
            const bool isDirectory = (record[25] & 0x02) != 0;
            const uint8_t nameLen = record[32];
            std::string name(reinterpret_cast<const char *>(record + 33), nameLen);
            pos += recordLen;

            if (name.size() == 1 && (name[0] == '\0' || name[0] == '\x01'))
            {
                continue; // "." and ".."
            }

            if (isDirectory)
            {
                walkDirectory(iso, extent, dataLen, prefix + name + "/", depth + 1);
            }
            else
            {
                g_isoFiles[normalize(prefix + name)] = IsoFile{extent, dataLen};
            }
        }
    }

    bool indexIso(const std::filesystem::path &isoPath)
    {
        std::ifstream iso(isoPath, std::ios::binary);
        if (!iso)
        {
            return false;
        }

        std::array<uint8_t, kSectorSize> pvd{};
        iso.seekg(16 * kSectorSize);
        iso.read(reinterpret_cast<char *>(pvd.data()), pvd.size());
        if (!iso || pvd[0] != 1 || std::memcmp(pvd.data() + 1, "CD001", 5) != 0)
        {
            return false;
        }

        const uint8_t *root = pvd.data() + 156;
        walkDirectory(iso, le32(root + 2), le32(root + 10), "", 0);
        return !g_isoFiles.empty();
    }

    // sceCdlFILE: u32 lsn, u32 size, char name[16], u8 date[8]. Returns 1 when found.
    void searchFileOnIso(uint8_t *rdram, R5900Context *ctx, PS2Runtime *)
    {
        const uint32_t fileAddr = getRegU32(ctx, 4);
        const uint32_t pathAddr = getRegU32(ctx, 5);

        std::string guestPath;
        for (uint32_t i = 0; i < 260; ++i)
        {
            const char c = static_cast<char>(rdram[(pathAddr + i) & PS2_RAM_MASK]);
            if (c == '\0')
            {
                break;
            }
            guestPath.push_back(c);
        }

        const std::string key = normalize(guestPath);
        const auto found = g_isoFiles.find(key);
        ctx->pc = getRegU32(ctx, 31);
        if (found == g_isoFiles.end())
        {
            std::cerr << "[rc_revenge_pro] sceCdSearchFile: not on disc: " << guestPath << std::endl;
            SET_GPR_S32(ctx, 2, 0);
            return;
        }

        std::array<uint8_t, 32> result{};
        std::memcpy(result.data(), &found->second.lsn, 4);
        std::memcpy(result.data() + 4, &found->second.size, 4);
        const std::string leaf = key.substr(key.rfind('/') + 1);
        std::strncpy(reinterpret_cast<char *>(result.data() + 8), leaf.c_str(), 15);
        for (size_t i = 0; i < result.size(); ++i)
        {
            rdram[(fileAddr + i) & PS2_RAM_MASK] = result[i];
        }
        SET_GPR_S32(ctx, 2, 1);
    }

    // The runtime's stubs for these two SDK functions abort. Their real behaviour,
    // from the game's own code:
    //   sceSdTransToIOP(src, iopDest, size, sync): SIF DMA from EE to IOP, 0 on success.
    //   sceSdCallBack(handler): stores handler in a guest global.
    void sdTransToIop(uint8_t *rdram, R5900Context *ctx, PS2Runtime *runtime)
    {
        const uint32_t src = getRegU32(ctx, 4) & PS2_RAM_MASK;
        const uint32_t dest = getRegU32(ctx, 5);
        const uint32_t size = getRegU32(ctx, 6);
        const bool inRange = static_cast<uint64_t>(src) + size <= PS2_RAM_SIZE;
        const bool ok = inRange && runtime->writeIopMemory(dest, rdram + src, size);
        ctx->pc = getRegU32(ctx, 31);
        SET_GPR_S32(ctx, 2, ok ? 0 : -1);
    }

    void sdCallBack(uint8_t *rdram, R5900Context *ctx, PS2Runtime *)
    {
        constexpr uint32_t kCallbackGlobal = 0x00321A30u;
        const uint32_t handler = getRegU32(ctx, 4);
        std::memcpy(rdram + kCallbackGlobal, &handler, sizeof(handler));
        ctx->pc = getRegU32(ctx, 31);
        SET_GPR_S32(ctx, 2, 0x00320000);
    }

    constexpr uint32_t kMemBlockInitAddr = 0x00194238u;
    constexpr uint32_t kMainAddr = 0x0012EA10u;
    // Taken from the game's heap, so keep it small: a 2.2 MB level load fails with more.
    constexpr uint32_t kHeapReserveBytes = 0x00100000u;
    // 1.1 MB, enough for a full-screen sceGsExecLoadImage packet.
    constexpr uint32_t kGuestHeapLimit = 0x005E0000u;
    // 128 KB main stack in the reserved area. The top of RAM belongs to the callback stacks.
    constexpr uint32_t kMainStackTop = 0x005FFD60u;
    constexpr uint32_t kGuestHeapStart = 0x004C7190u; // End of the ELF image.

    // The game runs its own heap from a fixed base (0x500000) to 0x1FF0000, and the
    // runtime's guest heap grows up from the end of the ELF right into it. Stubs such
    // as sceGsExecLoadImage build large packets there, destroying the game's block
    // headers. Move the game's heap up so the runtime and the main stack get their own space.
    void memBlockInitWithReservedHeap(uint8_t *rdram, R5900Context *ctx, PS2Runtime *runtime)
    {
        const uint32_t base = getRegU32(ctx, 4);
        const uint32_t size = getRegU32(ctx, 5);
        const uint32_t movedBase = base + kHeapReserveBytes;
        SET_GPR_U32(ctx, 4, movedBase);
        SET_GPR_U32(ctx, 5, size - kHeapReserveBytes);

        const uint32_t usedEnd = runtime->guestHeapEnd();
        if (usedEnd <= kGuestHeapStart)
        {
            runtime->configureGuestHeap(kGuestHeapStart, kGuestHeapLimit);
        }
        std::cout << std::hex << "[rc_revenge_pro] game heap 0x" << movedBase << " size 0x" << size - kHeapReserveBytes
                  << ", guest heap end was 0x" << usedEnd << std::dec << std::endl;
        MemBlockInit_0x194238(rdram, ctx, runtime);
    }

    // The runtime sets sp to the bottom of the 1 MB region SetupThread reserves. That
    // address is inside the game's heap, so run main on a stack of its own.
    void mainOnTopOfRamStack(uint8_t *rdram, R5900Context *ctx, PS2Runtime *runtime)
    {
        SET_GPR_U32(ctx, 29, kMainStackTop);
        ps2_main_0x12ea10(rdram, ctx, runtime);
    }

    // The game passes whole .M2V files to sceMpegAddBs at once. The runtime's stub trims
    // its sequence-header search buffer to 3 bytes once it passes 2 MB, which discards
    // the header at the start of the 6.4 MB intro, so no frame ever decodes. Feed it in
    // pieces small enough that the header is found first.
    uint32_t g_wholeFileMpeg = 0u;

    void mpegAddBsInChunks(uint8_t *rdram, R5900Context *ctx, PS2Runtime *runtime)
    {
        constexpr uint32_t kChunkBytes = 0x00100000u;
        const uint32_t mpeg = getRegU32(ctx, 4);
        const uint32_t data = getRegU32(ctx, 5);
        const uint32_t size = getRegU32(ctx, 6);
        const uint32_t returnAddress = getRegU32(ctx, 31);

        uint32_t fed = 0u;
        while (fed < size)
        {
            const uint32_t chunk = std::min(kChunkBytes, size - fed);
            SET_GPR_U32(ctx, 4, mpeg);
            SET_GPR_U32(ctx, 5, data + fed);
            SET_GPR_U32(ctx, 6, chunk);
            ps2_stubs::sceMpegAddBs(rdram, ctx, runtime);
            const uint32_t consumed = getRegU32(ctx, 2);
            fed += consumed;
            if (consumed != chunk)
            {
                break;
            }
        }

        // The buffer is a complete movie, so drain the frames the decoder is holding back.
        SET_GPR_U32(ctx, 4, mpeg);
        ps2_stubs::sceMpegFlush(rdram, ctx, runtime);
        g_wholeFileMpeg = mpeg;

        std::cout << std::hex << "[rc_revenge_pro] sceMpegAddBs data=0x" << data << " size=0x" << size
                  << " fed=0x" << fed << std::dec << std::endl;
        ctx->pc = returnAddress;
        SET_GPR_S32(ctx, 2, static_cast<int32_t>(fed));
    }

    bool wholeFileMovieDrained(uint8_t *rdram, R5900Context *ctx, PS2Runtime *runtime)
    {
        if (g_wholeFileMpeg == 0u || getRegU32(ctx, 4) != g_wholeFileMpeg)
        {
            return false;
        }
        ps2_stubs::sceMpegIsRefBuffEmpty(rdram, ctx, runtime);
        return getRegU32(ctx, 2) != 0u;
    }

    // The runtime's sceMpegIsEnd only recognises the end of CD-streamed movies. For a movie
    // handed over whole, report the end once its frames are gone. Otherwise the game's
    // vblank handler blocks forever in sceMpegGetPicture, once per vblank.
    void mpegIsEnd(uint8_t *rdram, R5900Context *ctx, PS2Runtime *runtime)
    {
        const uint32_t returnAddress = getRegU32(ctx, 31);
        const bool drained = wholeFileMovieDrained(rdram, ctx, runtime);
        if (!drained)
        {
            ps2_stubs::sceMpegIsEnd(rdram, ctx, runtime);
        }
        else
        {
            SET_GPR_S32(ctx, 2, 1);
        }
        ctx->pc = returnAddress;
    }

    void mpegGetPicture(uint8_t *rdram, R5900Context *ctx, PS2Runtime *runtime)
    {
        const uint32_t returnAddress = getRegU32(ctx, 31);
        if (wholeFileMovieDrained(rdram, ctx, runtime))
        {
            ctx->pc = returnAddress;
            SET_GPR_S32(ctx, 2, 0);
            return;
        }
        // Must be set before the stub: it can block, and execution resumes at ctx->pc.
        ctx->pc = returnAddress;
        ps2_stubs::sceMpegGetPicture(rdram, ctx, runtime);
    }

    // The runtime's sceGsSetDefDispEnv leaves pmode and smode2 at zero, so every
    // sceGsPutDispEnv turns the display off and no frame is ever presented. Fill them in
    // the way the game's own SDK code does.
    void gsSetDefDispEnv(uint8_t *rdram, R5900Context *ctx, PS2Runtime *runtime)
    {
        const uint32_t env = getRegU32(ctx, 4);
        const uint32_t returnAddress = getRegU32(ctx, 31);
        ctx->pc = returnAddress;
        ps2_stubs::sceGsSetDefDispEnv(rdram, ctx, runtime);

        // sceGsGParam: s16 interlace, omode, ffmode, version.
        ps2_stubs::sceGsGetGParam(rdram, ctx, runtime);
        const uint32_t gparam = getRegU32(ctx, 2);
        int16_t interlace = 0;
        int16_t ffmode = 0;
        const uint8_t *gparamHost = getConstMemPtr(rdram, gparam);
        if (gparamHost)
        {
            std::memcpy(&interlace, gparamHost, sizeof(interlace));
            std::memcpy(&ffmode, gparamHost + 4, sizeof(ffmode));
        }
        const uint64_t pmode = 0x66u;
        const uint64_t smode2 = interlace == 0 ? 2u : (ffmode != 0 ? 3u : 1u);
        std::memcpy(rdram + (env & PS2_RAM_MASK), &pmode, sizeof(pmode));
        std::memcpy(rdram + ((env + 8u) & PS2_RAM_MASK), &smode2, sizeof(smode2));
        ctx->pc = returnAddress;
        SET_GPR_S32(ctx, 2, 0);
    }

    // Writes what the debug panel's Threads/Kernel/IOP tabs show to the file named
    // by RC_DEBUG_DUMP, so a hang can be inspected without the UI.
    void debugDumpLoop(PS2Runtime *runtime, std::string path)
    {
        constexpr uint32_t kTextStart = 0x00100000u;
        constexpr uint32_t kTextEnd = 0x001D5444u;
        constexpr uint32_t kStackScanBytes = 0x400u;

        std::ofstream out(path, std::ios::trunc);
        const uint8_t *rdram = runtime->memory().getRDRAM();
        for (unsigned tick = 0;; ++tick)
        {
            std::this_thread::sleep_for(std::chrono::seconds(5));

            const EeKernelSnapshot kernel = runtime->eeScheduler().snapshot();
            out << "=== t=" << (tick + 1) * 5 << "s running=" << kernel.runningThreadId
                << " eeCycle=" << kernel.eeCycle << " nextEvent=" << kernel.nextEventCycle << "\n";

            out << std::hex;
            for (const EeThreadSnapshot &t : kernel.threads)
            {
                out << "thread " << std::dec << t.id << std::hex
                    << " status=" << static_cast<int>(t.status)
                    << " wait=" << static_cast<int>(t.waitReason)
                    << " waitId=" << std::dec << t.waitId << std::hex
                    << " pc=" << t.pc << " ra=" << t.ra << " sp=" << t.sp
                    << " entry=" << t.entry << " prio=" << std::dec << t.currentPriority
                    << " wake=" << t.wakeupCount << " inv=" << t.invocationDepth << std::hex << "\n  stack:";
                for (uint32_t off = 0; off < kStackScanBytes; off += 4)
                {
                    uint32_t word = 0;
                    std::memcpy(&word, rdram + ((t.sp + off) & PS2_RAM_MASK), 4);
                    if (word >= kTextStart && word < kTextEnd && (word & 3u) == 0u)
                    {
                        out << " " << word;
                    }
                }
                out << "\n";
            }
            out << std::dec;
            for (const EeSemaphoreSnapshot &sema : kernel.semaphores)
            {
                out << "sema " << sema.id << " count=" << sema.count << "/" << sema.maxCount
                    << " waiters=" << sema.waiters << "\n";
            }
            for (const EeEventFlagSnapshot &flag : kernel.eventFlags)
            {
                out << "evf " << flag.id << " bits=0x" << std::hex << flag.bits << std::dec
                    << " waiters=" << flag.waiters << "\n";
            }

            {
                // MemBlock free list: sentinel at 0x1FA960, +0x14 forward link, +4 size.
                const auto word = [rdram](uint32_t addr)
                {
                    uint32_t value = 0;
                    std::memcpy(&value, rdram + (addr & PS2_RAM_MASK), 4);
                    return value;
                };
                constexpr uint32_t kSentinel = 0x001FA960u;
                out << "heap free:" << std::hex;
                uint32_t block = word(kSentinel + 0x14u);
                uint32_t total = 0;
                int count = 0;
                bool cycle = false;
                std::vector<uint32_t> seen;
                while (block != kSentinel && count < 20000)
                {
                    if (std::find(seen.begin(), seen.end(), block) != seen.end())
                    {
                        cycle = true;
                        break;
                    }
                    seen.push_back(block);
                    const uint32_t size = word(block + 4u);
                    if (count < 10)
                    {
                        out << " " << block << "(sz=" << size << ",st=" << word(block) << ",next=" << word(block + 0x14u) << ")";
                    }
                    total += size;
                    block = word(block + 0x14u);
                    ++count;
                }
                out << " count=" << std::dec << count << " totalFree=" << total << " cycle=" << cycle
                    << (cycle ? " at " : "");
                if (cycle)
                {
                    out << std::hex << block << std::dec;
                }
                out << "\n";
            }
            {
                const GSRegisters &regs = runtime->memory().gs();
                const GSDebugSnapshot gsState = runtime->gs().getDebugSnapshot();
                const std::vector<GSDebugHistoryEntry> history = runtime->gs().getDebugHistory();
                size_t kinds[5] = {};
                for (const GSDebugHistoryEntry &entry : history)
                {
                    ++kinds[static_cast<size_t>(entry.kind) & 4u];
                }
                out << std::hex << "gs pmode=" << regs.pmode << " smode2=" << regs.smode2
                    << " dispfb1=" << regs.dispfb1 << " display1=" << regs.display1
                    << " dispfb2=" << regs.dispfb2 << " display2=" << regs.display2
                    << " bgcolor=" << regs.bgcolor << " csr=" << regs.csr.load()
                    << std::dec << " | hostFrame=" << gsState.hasHostPresentationFrame
                    << " " << gsState.hostPresentationWidth << "x" << gsState.hostPresentationHeight
                    << " displayFbp=" << gsState.hostPresentationDisplayFbp
                    << " history[gif,reg,draw,xfer,present]=" << kinds[0] << "," << kinds[1] << "," << kinds[2]
                    << "," << kinds[3] << "," << kinds[4] << "\n";

                // Summarise the presented frame so an image can be told from a solid colour.
                std::vector<uint8_t> pixels;
                uint32_t width = 0;
                uint32_t height = 0;
                if (runtime->gs().copyLatchedHostPresentationFrame(pixels, width, height, nullptr, nullptr, nullptr) &&
                    width != 0u && height != 0u)
                {
                    uint64_t sum[3] = {};
                    uint32_t nonBlack = 0;
                    uint32_t magenta = 0;
                    std::vector<uint32_t> distinct;
                    const size_t count = pixels.size() / 4u;
                    for (size_t i = 0; i < count; i += 7u)
                    {
                        const uint8_t *px = pixels.data() + i * 4u;
                        sum[0] += px[0];
                        sum[1] += px[1];
                        sum[2] += px[2];
                        nonBlack += (px[0] | px[1] | px[2]) != 0u;
                        magenta += px[0] > 240u && px[1] < 16u && px[2] > 240u;
                        uint32_t colour = 0;
                        std::memcpy(&colour, px, 3);
                        if (distinct.size() < 4096u && std::find(distinct.begin(), distinct.end(), colour) == distinct.end())
                        {
                            distinct.push_back(colour);
                        }
                    }
                    const uint64_t samples = std::max<uint64_t>(1u, (count + 6u) / 7u);
                    out << "frame " << width << "x" << height << " avgRGB=" << sum[0] / samples << "," << sum[1] / samples << ","
                        << sum[2] / samples << " nonBlack%=" << nonBlack * 100u / samples << " magenta%=" << magenta * 100u / samples
                        << " distinctColours=" << distinct.size() << "\n";
                }
                else
                {
                    out << "frame none\n";
                }
            }
            const ps2x::iop::DebugSnapshot iop = runtime->iopDebugSnapshot();
            out << "iop cycles=" << iop.emulatorCycles << " instr=" << iop.emulatorInstructions
                << " modules=" << iop.emulatorLoadedModules << " threads=" << iop.emulatorThreads
                << " rpcServers=" << iop.emulatorRpcServers << "\n";
            for (const ps2x::iop::DebugService &service : iop.services)
            {
                out << "service " << service.name << " active=" << service.active;
                for (const uint32_t sid : service.sids)
                {
                    out << " sid=0x" << std::hex << sid << std::dec;
                }
                for (const ps2x::iop::DebugMetric &metric : service.metrics)
                {
                    out << " " << metric.name << "=" << metric.value;
                }
                out << "\n";
            }
            for (const std::string &diagnostic : iop.diagnostics)
            {
                out << "diag " << diagnostic << "\n";
            }
            out.flush();
        }
    }

    void applyRcRevengePro(PS2Runtime &runtime)
    {
        PS2Runtime::IoPaths paths = PS2Runtime::getIoPaths();
        const std::filesystem::path isoPath = paths.elfDirectory.parent_path() / kIsoName;
        if (!indexIso(isoPath))
        {
            std::cerr << "[rc_revenge_pro] could not read " << isoPath
                      << "; disc reads will fail" << std::endl;
            return;
        }

        paths.cdImage = isoPath;
        PS2Runtime::setIoPaths(paths);
        runtime.replaceFunction(kSceCdSearchFileAddr, &searchFileOnIso);
        runtime.replaceFunction(0x001CA4D0u, &sdTransToIop);
        runtime.replaceFunction(0x001CA540u, &sdCallBack);
        runtime.replaceFunction(kMemBlockInitAddr, &memBlockInitWithReservedHeap);
        runtime.replaceFunction(kMainAddr, &mainOnTopOfRamStack);
        runtime.replaceFunction(0x001CE9A0u, &mpegAddBsInChunks);
        runtime.replaceFunction(0x001C3658u, &gsSetDefDispEnv);
        runtime.replaceFunction(0x001CEAF0u, &mpegIsEnd);
        runtime.replaceFunction(0x001CE9D8u, &mpegGetPicture);
        if (const char *dumpPath = std::getenv("RC_DEBUG_DUMP"))
        {
            std::thread(debugDumpLoop, &runtime, std::string(dumpPath)).detach();
        }
        std::cout << "[rc_revenge_pro] indexed " << g_isoFiles.size() << " files from " << isoPath << std::endl;
    }
}

PS2_REGISTER_GAME_OVERRIDE("RC Revenge Pro disc access", "SLUS_201.53", 0x00100008u, 0u, &applyRcRevengePro)

# RC Revenge Pro (SLUS-20153) - links PS2Recomp output against ps2xRuntime.
# The repo is used read-only: nothing is generated inside it.
cmake_minimum_required(VERSION 3.21)
project(RCRevengeProRecomp C CXX)

set(CMAKE_CXX_STANDARD 20)
set(CMAKE_CXX_STANDARD_REQUIRED ON)
if(NOT CMAKE_BUILD_TYPE)
    set(CMAKE_BUILD_TYPE Release)
endif()

set(PS2RECOMP_DIR "$ENV{HOME}/PS2Recomp" CACHE PATH "PS2Recomp checkout")

# Reuse the dependencies already downloaded by the repo's own build.
foreach(dep raylib imgui rlimgui)
    string(TOUPPER ${dep} DEP)
    set(src "${PS2RECOMP_DIR}/out/build/_deps/${dep}-src")
    if(EXISTS "${src}")
        set(FETCHCONTENT_SOURCE_DIR_${DEP} "${src}" CACHE PATH "")
    endif()
endforeach()

set(PS2X_ENABLE_AGRESSIVE_LOGS OFF CACHE BOOL "")

# ps2xRuntime uses SSE4 intrinsics, which GCC rejects at -O1+ without these.
add_compile_options(-msse4.2)

add_subdirectory("${PS2RECOMP_DIR}/ps2xIOP" ps2xIOP EXCLUDE_FROM_ALL)
add_subdirectory("${PS2RECOMP_DIR}/ps2xRuntime" ps2xRuntime EXCLUDE_FROM_ALL)

file(GLOB GAME_SOURCES CONFIGURE_DEPENDS "${CMAKE_CURRENT_SOURCE_DIR}/output/*.cpp")

add_executable(rc_revenge_pro
    ${GAME_SOURCES}
    "${PS2RECOMP_DIR}/ps2xRuntime/src/main.cpp"
    "${PS2RECOMP_DIR}/ps2xRuntime/src/lib/ps2_debug_panel.cpp"
)
target_include_directories(rc_revenge_pro PRIVATE "${CMAKE_CURRENT_SOURCE_DIR}/output")
target_link_libraries(rc_revenge_pro PRIVATE ps2_runtime rlImGui imgui)
target_compile_definitions(rc_revenge_pro PRIVATE PS2X_ENABLE_DEBUG_UI=1)

target_sources(rc_revenge_pro PRIVATE overrides/rc_revenge_pro_overrides.cpp)
set_source_files_properties(overrides/rc_revenge_pro_overrides.cpp PROPERTIES
    SKIP_UNITY_BUILD_INCLUSION TRUE)

set_target_properties(rc_revenge_pro PROPERTIES
    UNITY_BUILD ON
    UNITY_BUILD_BATCH_SIZE 32
)
# -O3 on 140 MB of generated code is too slow and memory hungry. Set on the
# target, because per-source options would exclude the files from unity builds.
target_compile_options(rc_revenge_pro PRIVATE -O1)
